<?php
$host = "localhost";
$db = "smartlibrary"; 
$user = "root";      
$pass = "";          

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco: " . $e->getMessage());
}
