<?php

class AuthController {

    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function login($email, $senha) {

        $sql = $this->pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
        $sql->execute([$email]);

        if ($sql->rowCount() === 1) {
            $user = $sql->fetch();

            if (password_verify($senha, $user['senha'])) {
                session_start();
                $_SESSION['usuario_id'] = $user['id'];
                $_SESSION['nome'] = $user['nome'];
                $_SESSION['perfil'] = $user['perfil'];
                return true;
            }
        }

        return false;
    }
}
