<?php
require "../includes/connection.php";
require "../src/controllers/AuthController.php";

$auth = new AuthController($pdo);
$erro = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    if ($auth->login($email, $senha)) {
        header("Location: dashboard.php");
        exit;
    } else {
        $erro = "Email ou senha incorretos.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/style.css">
    <title>Login - SmartLibrary</title>
</head>
<body>

<div class="login-container">
    <h2>SmartLibrary</h2>

    <form method="POST">
        <label>Email</label>
        <input type="email" name="email" required>

        <label>Senha</label>
        <input type="password" name="senha" required>

        <button type="submit">Entrar</button>

        <?php if ($erro): ?>
        <p class="erro"><?= $erro ?></p>
        <?php endif; ?>
    </form>
</div>

</body>
</html>
