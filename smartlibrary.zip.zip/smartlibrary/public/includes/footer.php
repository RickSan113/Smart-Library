</div>

<footer style="
    background: #1f1f1f;
    padding: 20px;
    text-align: center;
    margin-top: 40px;
    border-top: 1px solid #333;
    color: #aaa;
    font-size: 14px;
">
    SmartLibrary © <?php echo date("Y"); ?> — Sistema de Biblioteca Inteligente
</footer>

</body>
</html>
