<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>SmartLibrary</title>
    <link rel="stylesheet" href="css/style.css">

    <style>
        
        .navbar {
            background: #1f1f1f;
            padding: 15px 25px;
            display: flex;
            align-items: center;
            border-bottom: 1px solid #333;
        }

        .navbar a {
            color: #ffffff;
            text-decoration: none;
            margin-right: 20px;
            font-size: 18px;
            font-weight: 500;
            padding: 6px 10px;
            border-radius: 6px;
            transition: 0.2s ease;
        }

        .navbar a:hover {
            background: #2e2e2e;
            color: #00eaff;
        }

        .navbar .right {
            margin-left: auto;
        }

        
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #121212;
            color: white;
        }

        .content {
            padding: 20px 30px;
        }

        h1, h2, h3 {
            color: #00eaff;
        }

        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #1b1b1b;
            border-radius: 8px;
            overflow: hidden;
        }

        table th {
            background: #222;
            padding: 12px;
            text-align: left;
            color: #00eaff;
        }

        table td {
            padding: 10px;
            border-bottom: 1px solid #333;
        }

        table tr:hover {
            background: #262626;
        }

        
        .btn {
            padding: 10px 18px;
            background: #00eaff;
            color: #000;
            font-weight: bold;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
            margin: 10px 0;
            transition: 0.2s;
        }

        .btn:hover {
            background: #00bcd4;
        }

        .btn-red {
            background: #ff4b4b;
            color: #000;
        }

        .btn-red:hover {
            background: #d93434;
        }

        
        input, select {
            width: 300px;
            padding: 10px;
            background: #1b1b1b;
            border: 1px solid #333;
            border-radius: 6px;
            color: #fff;
        }

        label {
            color: #00eaff;
            font-weight: bold;
        }
    </style>
    <script>
document.addEventListener("DOMContentLoaded", () => {
    const body = document.body;
    const btn = document.getElementById("themeToggle");

    // Carregar tema salvo
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "light") {
        body.classList.add("light");
        btn.textContent = "☀️";
    }

    // Alterar tema ao clicar
    btn.addEventListener("click", () => {
        body.classList.toggle("light");

        if (body.classList.contains("light")) {
            localStorage.setItem("theme", "light");
            btn.textContent = "☀️";
        } else {
            localStorage.setItem("theme", "dark");
            btn.textContent = "🌙";
        }
    });
});
</script>

</head>

<body>

<div class="navbar">
    <a href="index.php">🏠 Início</a>
    <a href="livros.php">📚 Livros</a>
    <a href="emprestimos.php">🔄 Empréstimos</a>
    <a href="recomendacoes.php">⭐ Recomendações</a>
    <a href="usuarios.php">👤 Usuários</a>
    <a class="btn-red" href="logout.php">🚪 Sair</a>
    




    <div class="right">
        <a href="logout.php">🚪 Sair</a>
    </div>
</div>

<div class="content">
