<?php
require "../includes/connection.php";
require "../src/controllers/AuthController.php";
require "includes/header.php";

session_start();
if (isset($_SESSION['usuario_id'])) {
    header("Location: dashboard.php");
    exit;
}

$auth = new AuthController($pdo);
$erro = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $senha = $_POST["senha"] ?? "";

    if ($auth->login($email, $senha)) {
        header("Location: dashboard.php");
        exit;
    } else {
        $erro = "Email ou senha incorretos. Verifique e tente novamente.";
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Login — SmartLibrary</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="login-body">

  <main class="login-wrap">
    <section class="login-panel">
      <div class="brand">
        <div class="logo">📚</div>
        <h1>SmartLibrary</h1>
        <p class="subtitle">Biblioteca Inteligente — Acesse sua conta</p>
      </div>

      <?php if ($erro): ?>
        <div class="alert"><?= htmlspecialchars($erro) ?></div>
      <?php endif; ?>

      <form method="post" class="login-form" autocomplete="off" novalidate>
        <label for="email">Email</label>
        <input id="email" name="email" type="email" placeholder="seu@exemplo.com" required>

        <label for="senha">Senha</label>
        <div class="password-row">
          <input id="senha" name="senha" type="password" placeholder="••••••••" required>
          <button type="button" class="toggle-pass" aria-label="Mostrar senha" onclick="togglePass()">👁️</button>
        </div>

        <div class="form-actions">
          <button type="submit" class="btn">Entrar</button>
        </div>

        <p class="small">Problemas para entrar? Peça ao Administrador para resetar a senha.</p>
      </form>

      <footer class="login-footer">
        <small>SmartLibrary • © <?= date("Y") ?></small>
      </footer>
    </section>

    <aside class="login-info">
      <h2>Gerencie o acervo com inteligência</h2>
      <p>Cadastre livros, registre empréstimos e obtenha recomendações com base no histórico de leitura.</p>
      <ul>
        <li>Interface moderna</li>
        <li>Recomendações por tags</li>
        <li>Controle de empréstimos</li>
      </ul>
    </aside>
  </main>

<script>
function togglePass(){
  const p = document.getElementById('senha');
  const btn = document.querySelector('.toggle-pass');
  if (p.type === 'password') {
    p.type = 'text';
    btn.textContent = '🙈';
  } else {
    p.type = 'password';
    btn.textContent = '👁️';
  }
}
</script>
</body>
</html>
