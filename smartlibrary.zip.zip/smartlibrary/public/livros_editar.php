<?php
require "../includes/auth.php";
require "../includes/connection.php";
require "../src/controllers/LivroController.php";
require "includes/header.php";

$controller = new LivroController($pdo);
$id = $_GET["id"];
$livro = $controller->buscar($id);

if (!$livro) {
    echo "Livro não encontrado!";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $controller->atualizar($id, $_POST["titulo"], $_POST["autor"], $_POST["genero"], $_POST["tags"], $_POST["ano"]);
    header("Location: livros.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Editar Livro</title>
</head>
<body>
<h1>Editar Livro</h1>

<form method="POST">
    <label>Título</label><br>
    <input type="text" name="titulo" value="<?= $livro['titulo'] ?>" required><br><br>

    <label>Autor</label><br>
    <input type="text" name="autor" value="<?= $livro['autor'] ?>" required><br><br>

    <label>Gênero</label><br>
    <input type="text" name="genero" value="<?= $livro['genero'] ?>" required><br><br>

    <label>Tags</label><br>
    <input type="text" name="tags" value="<?= $livro['tags'] ?>"><br><br>

    <label>Ano</label><br>
    <input type="number" name="ano" value="<?= $livro['ano'] ?>"><br><br>

    <button type="submit">Salvar alterações</button>
</form>

</body>
</html>
