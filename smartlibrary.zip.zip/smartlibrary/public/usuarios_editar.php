<?php
require "../includes/auth.php";
require "../includes/connection.php";
require "includes/header.php";
require "../src/controllers/UsuarioController.php";

$controller = new UsuarioController($pdo);

$id = $_GET["id"];
$usuario = $controller->buscar($id);

if (!$usuario) {
    echo "Usuário não encontrado.";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $controller->atualizar($id, $_POST["nome"], $_POST["email"], $_POST["perfil"]);

    if (!empty($_POST["senha"])) {
        $controller->atualizarSenha($id, $_POST["senha"]);
    }

    header("Location: usuarios.php");
    exit;
}
?>

<h1>✏️ Editar Usuário</h1>

<form method="POST">
    <label>Nome</label><br>
    <input type="text" name="nome" value="<?= $usuario['nome'] ?>" required><br><br>

    <label>Email</label><br>
    <input type="email" name="email" value="<?= $usuario['email'] ?>" required><br><br>

    <label>Senha (deixe em branco para não alterar)</label><br>
    <input type="password" name="senha" placeholder="Nova senha"><br><br>

    <label>Perfil</label><br>
    <select name="perfil">
        <option <?= $usuario['perfil']=='admin'?'selected':'' ?> value="admin">Admin</option>
        <option <?= $usuario['perfil']=='usuario'?'selected':'' ?> value="usuario">Usuário</option>
    </select><br><br>

    <button class="btn" type="submit">Salvar alterações</button>
</form>

<?php include "includes/footer.php"; ?>
