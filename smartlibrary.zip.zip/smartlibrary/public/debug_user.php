<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require "../includes/connection.php";

// email do admin
$email = "admin@admin.com";

$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
$stmt->execute([$email]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "Usuário NÃO existe no banco.";
    exit;
}

echo "<h2>Usuário encontrado:</h2>";
echo "<pre>";
print_r($user);
echo "</pre>";

echo "<h2>Testando senha 1234...</h2>";

if (password_verify("1234", $user["senha"])) {
    echo "<p style='color:green;'>Senha CORRETA ✔</p>";
} else {
    echo "<p style='color:red;'>Senha ERRADA ❌</p>";
}
