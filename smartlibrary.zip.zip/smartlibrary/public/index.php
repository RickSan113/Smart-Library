<?php
require "../includes/auth.php";
require "../includes/connection.php";
require "includes/header.php";


$totalLivros = $pdo->query("SELECT COUNT(*) FROM livros")->fetchColumn();
$totalUsuarios = $pdo->query("SELECT COUNT(*) FROM usuarios")->fetchColumn();
$totalEmprestimos = $pdo->query("SELECT COUNT(*) FROM emprestimos")->fetchColumn();
$emprestimosAtivos = $pdo->query("SELECT COUNT(*) FROM emprestimos WHERE status='ativo'")->fetchColumn();
?>

<h1>📚 Bem-vindo ao SmartLibrary</h1>
<p>Gerencie livros, empréstimos, usuários e veja recomendações inteligentes!</p>

<div style="
    display: flex;
    gap: 25px;
    margin-top: 25px;
    flex-wrap: wrap;
">

    
    <div style="
        background: #1f1f1f;
        padding: 20px;
        border-radius: 12px;
        width: 220px;
        box-shadow: 0 0 10px #000;
    ">
        <h2 style="color:#00eaff;">📚 Livros</h2>
        <p>Total: <?= $totalLivros ?></p>
        <a href="livros.php" class="btn">Ver Livros</a>
    </div>

    
    <div style="
        background: #1f1f1f;
        padding: 20px;
        border-radius: 12px;
        width: 220px;
        box-shadow: 0 0 10px #000;
    ">
        <h2 style="color:#00eaff;">🔄 Empréstimos</h2>
        <p>Total: <?= $totalEmprestimos ?></p>
        <p>Ativos: <?= $emprestimosAtivos ?></p>
        <a href="emprestimos.php" class="btn">Gerenciar</a>
    </div>

    
    <div style="
        background: #1f1f1f;
        padding: 20px;
        border-radius: 12px;
        width: 220px;
        box-shadow: 0 0 10px #000;
    ">
        <h2 style="color:#00eaff;">👤 Usuários</h2>
        <p>Total: <?= $totalUsuarios ?></p>
        <a href="#" class="btn" onclick="alert('CRUD de usuários não criado ainda!')">Ver usuários</a>
    </div>

    
    <div style="
        background: #1f1f1f;
        padding: 20px;
        border-radius: 12px;
        width: 220px;
        box-shadow: 0 0 10px #000;
    ">
        <h2 style="color:#00eaff;">⭐ Recomendações</h2>
        <p>Baseado no histórico</p>
        <a href="recomendacoes.php" class="btn">Ver recomendações</a>
    </div>

</div>

<?php include "includes/footer.php"; ?>
