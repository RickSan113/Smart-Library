<?php
require "../includes/auth.php";
require "../includes/connection.php";
require "includes/header.php";
require "../src/controllers/UsuarioController.php";

$controller = new UsuarioController($pdo);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $controller->criar($_POST["nome"], $_POST["email"], $_POST["senha"], $_POST["perfil"]);
    header("Location: usuarios.php");
    exit;
}
?>

<h1>➕ Novo Usuário</h1>

<form method="POST">
    <label>Nome</label><br>
    <input type="text" name="nome" required><br><br>

    <label>Email</label><br>
    <input type="email" name="email" required><br><br>

    <label>Senha</label><br>
    <input type="password" name="senha" required><br><br>

    <label>Perfil</label><br>
    <select name="perfil">
        <option value="admin">Admin</option>
        <option value="usuario">Usuário</option>
    </select><br><br>

    <button class="btn" type="submit">Salvar</button>
</form>

<?php include "includes/footer.php"; ?>
