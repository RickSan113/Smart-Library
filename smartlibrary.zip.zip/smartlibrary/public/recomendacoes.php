<?php
require "../includes/auth.php";
require "../includes/connection.php";
require "includes/header.php";
require "../src/controllers/LivroController.php";

$controller = new LivroController($pdo);

$id_usuario = $_SESSION["user"]["id"];

$recomendacoes = $controller->recomendar($id_usuario);
?>

<h1>📚 Recomendações para você</h1>

<?php if (empty($recomendacoes)): ?>
    <p>Faça alguns empréstimos primeiro, assim poderei recomendar livros parecidos!</p>
<?php else: ?>

<ul>
    <?php foreach ($recomendacoes as $livro): ?>
        <li>
            <b><?= $livro["titulo"] ?></b> — <?= $livro["autor"] ?>
            <br>
            <small>Tags: <?= $livro["tags"] ?></small>
        </li>
        <br>
    <?php endforeach; ?>
</ul>

<?php endif; ?>

<?php require "includes/footer.php"; ?>
