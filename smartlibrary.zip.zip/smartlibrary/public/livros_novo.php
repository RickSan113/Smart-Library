<?php
require "../includes/auth.php";
require "../includes/connection.php";
require "../src/controllers/LivroController.php";
require "includes/header.php";
$controller = new LivroController($pdo);
$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $controller->criar($_POST["titulo"], $_POST["autor"], $_POST["genero"], $_POST["tags"], $_POST["ano"]);
    header("Location: livros.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Novo Livro</title>
</head>
<body>
<h1>Novo Livro</h1>

<form method="POST">
    <label>Título</label><br>
    <input type="text" name="titulo" required><br><br>

    <label>Autor</label><br>
    <input type="text" name="autor" required><br><br>

    <label>Gênero</label><br>
    <input type="text" name="genero" required><br><br>

    <label>Tags</label><br>
    <input type="text" name="tags"><br><br>

    <label>Ano</label><br>
    <input type="number" name="ano"><br><br>

    <button type="submit">Salvar</button>
</form>

</body>
</html>
