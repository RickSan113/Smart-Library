<?php
require "../includes/auth.php";
require "../includes/connection.php";
require "../src/controllers/EmprestimoController.php";
require "includes/header.php";

$controller = new EmprestimoController($pdo);
$emprestimos = $controller->listar();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Empréstimos</title>
</head>
<body>

<h1>Empréstimos</h1>
<a href="emprestimos_novo.php">+ Novo Empréstimo</a>

<table border="1" cellpadding="8" cellspacing="0">
<tr>
    <th>ID</th>
    <th>Usuário</th>
    <th>Livro</th>
    <th>Data Empréstimo</th>
    <th>Data Devolução</th>
    <th>Status</th>
    <th>Ações</th>
</tr>

<?php foreach ($emprestimos as $e): ?>
<tr>
    <td><?= $e['id'] ?></td>
    <td><?= $e['usuario'] ?></td>
    <td><?= $e['livro'] ?></td>
    <td><?= $e['data_emprestimo'] ?></td>
    <td><?= $e['data_devolucao'] ?: '-' ?></td>
    <td><?= $e['status'] ?></td>
    <td>
        <?php if ($e['status'] == 'ativo'): ?>
            <a href="emprestimos_devolver.php?id=<?= $e['id'] ?>">Devolver</a>
        <?php else: ?>
            -
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>
</table>

</body>
</html>
