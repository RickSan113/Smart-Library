<?php
require "../includes/auth.php";
require "../includes/connection.php";
require "../src/controllers/UsuarioController.php";
require "includes/header.php";

$controller = new UsuarioController($pdo);

if (isset($_GET["id"])) {
    $controller->excluir($_GET["id"]);
}

header("Location: usuarios.php");
exit;
