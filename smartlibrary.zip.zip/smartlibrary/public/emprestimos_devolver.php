<?php
require "../includes/auth.php";
require "../includes/connection.php";
require "../src/controllers/EmprestimoController.php";
require "includes/header.php";
$controller = new EmprestimoController($pdo);

if (isset($_GET["id"])) {
    $controller->devolver($_GET["id"]);
}

header("Location: emprestimos.php");
exit;
