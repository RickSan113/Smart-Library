<?php
require "../includes/auth.php";
require "../includes/connection.php";
require "../src/controllers/EmprestimoController.php";
require "../src/controllers/LivroController.php";
require "includes/header.php";
$controller = new EmprestimoController($pdo);
$livrosController = new LivroController($pdo);

$livros = array_filter($livrosController->listar(), fn($l) => $l["status"] == "disponivel");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $controller->registrar($_POST["id_usuario"], $_POST["id_livro"]);
    header("Location: emprestimos.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Novo Empréstimo</title>
</head>
<body>

<h1>Novo Empréstimo</h1>

<form method="POST">
    <label>ID do Usuário</label><br>
    <input type="number" name="id_usuario" required><br><br>

    <label>Livro</label><br>
    <select name="id_livro" required>
        <?php foreach ($livros as $l): ?>
            <option value="<?= $l['id'] ?>"><?= $l['titulo'] ?></option>
        <?php endforeach; ?>
    </select><br><br>

    <button type="submit">Registrar</button>
</form>

</body>
</html>
