<?php
require "../includes/connection.php";

echo "<h2>Teste de Conexão ao Banco de Dados</h2>";

if (isset($pdo)) {
    echo "<p style='color:green; font-size:22px;'>Conexão bem-sucedida! 🎉</p>";
} else {
    echo "<p style='color:red;'>Falha na conexão.</p>";
}
