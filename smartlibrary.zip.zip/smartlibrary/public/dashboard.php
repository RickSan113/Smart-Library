<?php
require "../includes/auth.php";
require "includes/header.php";
?>

<h1>Bem-vindo, <?= $_SESSION['nome'] ?>!</h1>
<p>Sistema SmartLibrary iniciado com sucesso.</p>

<a href="livros.php">Gerenciar Livros</a><br>
<a href="emprestimos.php">Gerenciar Empréstimos</a><br>
<a href="recomendacoes.php">Ver Recomendações</a><br>
