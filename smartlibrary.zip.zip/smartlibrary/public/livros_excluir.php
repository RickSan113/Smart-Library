<?php
require "../includes/auth.php";
require "../includes/connection.php";
require "../src/controllers/LivroController.php";
require "includes/header.php";
$controller = new LivroController($pdo);

if (isset($_GET["id"])) {
    $controller->excluir($_GET["id"]);
}

header("Location: livros.php");
exit;
