<?php
require "../includes/auth.php";
require "../includes/connection.php";
require "includes/header.php";
require "../src/controllers/UsuarioController.php";

$controller = new UsuarioController($pdo);
$usuarios = $controller->listar();
?>

<h1>👤 Usuários</h1>

<a class="btn" href="usuarios_novo.php">+ Novo Usuário</a>

<table>
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Email</th>
        <th>Perfil</th>
        <th>Ações</th>
    </tr>

    <?php foreach ($usuarios as $u): ?>
    <tr>
        <td><?= $u['id'] ?></td>
        <td><?= $u['nome'] ?></td>
        <td><?= $u['email'] ?></td>
        <td><?= $u['perfil'] ?></td>
        <td>
            <a class="btn" href="usuarios_editar.php?id=<?= $u['id'] ?>">Editar</a>
            <a class="btn-red" href="usuarios_excluir.php?id=<?= $u['id'] ?>"
               onclick="return confirm('Excluir usuário?')">Excluir</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<?php include "includes/footer.php"; ?>
