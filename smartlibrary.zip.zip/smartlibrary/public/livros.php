<?php include "includes/header.php"; ?>

<?php
require "../includes/auth.php";
require "../includes/connection.php";
require "../src/controllers/LivroController.php";

$controller = new LivroController($pdo);
$livros = $controller->listar();
?>

<h1>Livros</h1>

<a href="livros_novo.php" style="color:#00c8ff;">+ Novo Livro</a>

<table border="1" cellpadding="8" cellspacing="0" style="margin-top:20px; width:100%;">
    <tr>
        <th>ID</th>
        <th>Título</th>
        <th>Autor</th>
        <th>Gênero</th>
        <th>Tags</th>
        <th>Ano</th>
        <th>Ações</th>
    </tr>

    <?php foreach ($livros as $livro): ?>
    <tr>
        <td><?= $livro['id'] ?></td>
        <td><?= $livro['titulo'] ?></td>
        <td><?= $livro['autor'] ?></td>
        <td><?= $livro['genero'] ?></td>
        <td><?= $livro['tags'] ?></td>
        <td><?= $livro['ano'] ?></td>
        <td>
            <a href="livros_editar.php?id=<?= $livro['id'] ?>">Editar</a> |
            <a href="livros_excluir.php?id=<?= $livro['id'] ?>" onclick="return confirm('Excluir este livro?')">Excluir</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<?php include "includes/footer.php"; ?>
