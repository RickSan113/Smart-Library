<?php

class Emprestimo {

    public static function listar($pdo) {
        $sql = $pdo->prepare("
            SELECT e.*, u.nome as usuario, l.titulo as livro 
            FROM emprestimos e
            JOIN usuarios u ON u.id = e.id_usuario
            JOIN livros l ON l.id = e.id_livro
            ORDER BY e.data_emprestimo DESC
        ");
        $sql->execute();
        return $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function registrar($pdo, $id_usuario, $id_livro) {
        $sql = $pdo->prepare("
            INSERT INTO emprestimos (id_usuario, id_livro, data_emprestimo, status)
            VALUES (?, ?, CURDATE(), 'ativo')
        ");

        
        $pdo->prepare("UPDATE livros SET status='emprestado' WHERE id=?")->execute([$id_livro]);

        return $sql->execute([$id_usuario, $id_livro]);
    }

    public static function devolver($pdo, $id_emprestimo) {

        
        $pdo->prepare("
            UPDATE emprestimos SET status='devolvido', data_devolucao=CURDATE()
            WHERE id=?
        ")->execute([$id_emprestimo]);

        
        $sql = $pdo->prepare("SELECT id_livro FROM emprestimos WHERE id=?");
        $sql->execute([$id_emprestimo]);
        $id_livro = $sql->fetchColumn();

        
        return $pdo->prepare("
            UPDATE livros SET status='disponivel' WHERE id=?
        ")->execute([$id_livro]);
    }
}
