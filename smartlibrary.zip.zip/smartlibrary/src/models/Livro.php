<?php

class Livro {

    public static function listar($pdo) {
        $sql = $pdo->prepare("SELECT * FROM livros ORDER BY titulo");
        $sql->execute();
        return $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function criar($pdo, $titulo, $autor, $genero, $tags, $ano) {
        $sql = $pdo->prepare("INSERT INTO livros (titulo, autor, genero, tags, ano) VALUES (?, ?, ?, ?, ?)");
        return $sql->execute([$titulo, $autor, $genero, $tags, $ano]);
    }

    public static function buscar($pdo, $id) {
        $sql = $pdo->prepare("SELECT * FROM livros WHERE id = ?");
        $sql->execute([$id]);
        return $sql->fetch(PDO::FETCH_ASSOC);
    }

    public static function atualizar($pdo, $id, $titulo, $autor, $genero, $tags, $ano) {
        $sql = $pdo->prepare("UPDATE livros SET titulo=?, autor=?, genero=?, tags=?, ano=? WHERE id=?");
        return $sql->execute([$titulo, $autor, $genero, $tags, $ano, $id]);
    }

    public static function excluir($pdo, $id) {
        $sql = $pdo->prepare("DELETE FROM livros WHERE id=?");
        return $sql->execute([$id]);
    }
public static function recomendar($pdo, $id_usuario) {

    
    $sql = $pdo->prepare("
        SELECT l.*
        FROM emprestimos e
        JOIN livros l ON l.id = e.id_livro
        WHERE e.id_usuario = ? AND e.status = 'devolvido'
    ");
    $sql->execute([$id_usuario]);
    $historico = $sql->fetchAll(PDO::FETCH_ASSOC);

    if (!$historico) {
        return []; 
    }

    
    $tags = [];

    foreach ($historico as $livro) {
        $livroTags = explode(",", $livro["tags"]);

        foreach ($livroTags as $tag) {
            $tag = trim(strtolower($tag));
            if ($tag) {
                if (!isset($tags[$tag])) {
                    $tags[$tag] = 0;
                }
                $tags[$tag]++;
            }
        }
    }

    
    arsort($tags);

    
    $tagsPrincipais = array_keys(array_slice($tags, 0, 3));

    
    $queryParts = [];
    foreach ($tagsPrincipais as $tag) {
        $queryParts[] = "tags LIKE '%$tag%'";
    }

    $sql = $pdo->prepare("
        SELECT * FROM livros
        WHERE (" . implode(" OR ", $queryParts) . ")
        AND id NOT IN (
            SELECT id_livro FROM emprestimos WHERE id_usuario = ?
        )
        LIMIT 5
    ");

    $sql->execute([$id_usuario]);

    return $sql->fetchAll(PDO::FETCH_ASSOC);
}

}
