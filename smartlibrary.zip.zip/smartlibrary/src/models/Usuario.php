<?php

class Usuario {

    public static function listar($pdo) {
        $sql = $pdo->prepare("SELECT * FROM usuarios ORDER BY nome ASC");
        $sql->execute();
        return $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function buscar($pdo, $id) {
        $sql = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
        $sql->execute([$id]);
        return $sql->fetch(PDO::FETCH_ASSOC);
    }

    public static function criar($pdo, $nome, $email, $senha, $perfil) {
        $hash = password_hash($senha, PASSWORD_BCRYPT);
        $sql = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, perfil) VALUES (?, ?, ?, ?)");
        return $sql->execute([$nome, $email, $hash, $perfil]);
    }

    public static function atualizar($pdo, $id, $nome, $email, $perfil) {
        $sql = $pdo->prepare("UPDATE usuarios SET nome=?, email=?, perfil=? WHERE id=?");
        return $sql->execute([$nome, $email, $perfil, $id]);
    }

    public static function atualizarSenha($pdo, $id, $senha) {
        $hash = password_hash($senha, PASSWORD_BCRYPT);
        $sql = $pdo->prepare("UPDATE usuarios SET senha=? WHERE id=?");
        return $sql->execute([$hash, $id]);
    }

    public static function excluir($pdo, $id) {
        $sql = $pdo->prepare("DELETE FROM usuarios WHERE id=?");
        return $sql->execute([$id]);
    }
}
