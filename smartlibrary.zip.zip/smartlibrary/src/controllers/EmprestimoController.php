<?php
require_once __DIR__ . "/../models/Emprestimo.php";

class EmprestimoController {

    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function listar() {
        return Emprestimo::listar($this->pdo);
    }

    public function registrar($id_usuario, $id_livro) {
        return Emprestimo::registrar($this->pdo, $id_usuario, $id_livro);
    }

    public function devolver($id) {
        return Emprestimo::devolver($this->pdo, $id);
    }
}
