<?php
require_once __DIR__ . "/../models/Usuario.php";

class UsuarioController {

    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function listar() {
        return Usuario::listar($this->pdo);
    }

    public function buscar($id) {
        return Usuario::buscar($this->pdo, $id);
    }

    public function criar($nome, $email, $senha, $perfil) {
        return Usuario::criar($this->pdo, $nome, $email, $senha, $perfil);
    }

    public function atualizar($id, $nome, $email, $perfil) {
        return Usuario::atualizar($this->pdo, $id, $nome, $email, $perfil);
    }

    public function atualizarSenha($id, $senha) {
        return Usuario::atualizarSenha($this->pdo, $id, $senha);
    }

    public function excluir($id) {
        return Usuario::excluir($this->pdo, $id);
    }
}
