<?php
require_once __DIR__ . "/../models/Livro.php";

class LivroController {

    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function listar() {
        return Livro::listar($this->pdo);
    }

    public function criar($titulo, $autor, $genero, $tags, $ano) {
        return Livro::criar($this->pdo, $titulo, $autor, $genero, $tags, $ano);
    }

    public function buscar($id) {
        return Livro::buscar($this->pdo, $id);
    }

    public function atualizar($id, $titulo, $autor, $genero, $tags, $ano) {
        return Livro::atualizar($this->pdo, $id, $titulo, $autor, $genero, $tags, $ano);
    }

    public function excluir($id) {
        return Livro::excluir($this->pdo, $id);
    }
    public function recomendar($id_usuario) {
    return Livro::recomendar($this->pdo, $id_usuario);
}

}
