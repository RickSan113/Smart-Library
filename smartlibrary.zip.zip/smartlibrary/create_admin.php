<?php
require "includes/connection.php";

$nome = "Administrador";
$email = "admin@admin.com";
$senha = password_hash("1234", PASSWORD_DEFAULT); // Criptografa a senha
$perfil = "admin";

$sql = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, perfil) VALUES (?, ?, ?, ?)");

try {
    $sql->execute([$nome, $email, $senha, $perfil]);
    echo "<h2 style='color:green;'>Administrador criado com sucesso! 🎉</h2>";
    echo "Email: <b>admin@admin.com</b><br>";
    echo "Senha: <b>1234</b>";
} catch (PDOException $e) {
    echo "<h2 style='color:red;'>Erro ao criar administrador:</h2>";
    echo $e->getMessage();
}
